/**
 * Pro subscription plan for teams - unlimited prompts, but limited team slots.
 * Adding a member uses up a slot; removing one gives it back.
 *
 * @author Sudip Bharati
 * @version 1.0
 */
public class ProPlan extends AIModel {

    private int availableSlots; // how many more team members can still be added

    /**
     * Creates a Pro Plan.
     *
     * @param modelName      name of the AI model
     * @param price          cost per 100,000 tokens in Rs.
     * @param parameterCount parameter count in billions
     * @param contextWindow  max context size e.g. "128K"
     * @param availableSlots number of team member slots available
     */
    public ProPlan(String modelName, double price, int parameterCount, String contextWindow, int availableSlots) {
        super(modelName, price, parameterCount, contextWindow);
        this.availableSlots = availableSlots;
    }

    /**
     * @return number of team slots still open
     */
    public int getAvailableSlots() {
        return availableSlots;
    }

    /**
     * Adds a team member if there's a free slot.
     *
     * @param memberName name of the person to add
     * @return confirmation or error if no slots left
     */
    public String addTeamMember(String memberName) {
        if (availableSlots <= 0) {
            return "No available slots. Cannot add " + memberName + ". Please upgrade your plan.";
        }
        availableSlots--;
        return memberName + " has been added to the team. Available slots remaining: " + availableSlots;
    }

    /**
     * Removes a team member and frees up their slot.
     *
     * @param memberName name of the person to remove
     * @return confirmation with updated slot count
     */
    public String removeTeamMember(String memberName) {
        availableSlots++;
        return memberName + " has been removed from the team. Available slots: " + availableSlots;
    }

    /**
     * Submits a prompt - no quota limit, just checks if it fits in the context window.
     *
     * @param promptText   the prompt text
     * @param outputTokens expected output token count
     * @return result summary or error if context window is exceeded
     */
    @Override
    public String enterPrompt(String promptText, int outputTokens) {
        int totalTokens = calculateTokens(promptText, outputTokens);
        int contextLimit = getContextWindowAsInt();

        if (totalTokens > contextLimit) {
            return "Request exceeds context window (" + getContextWindow() + "). "
                    + "Total tokens required: " + totalTokens + ". Please shorten your prompt or reduce expected output.";
        }

        return "Prompt submitted successfully. (Pro Plan - Unlimited)\n"
                + "Model   : " + getModelName() + "\n"
                + "Prompt  : " + promptText + "\n"
                + "Tokens  : " + totalTokens + " (input + output)";
    }

    /**
     * @return formatted plan summary including available team slots
     */
    @Override
    public String display() {
        return "[ Pro Plan ]\n"
                + "Model Name      : " + getModelName() + "\n"
                + "Price (per 1L tokens) : Rs. " + getPrice() + "\n"
                + "Parameters      : " + getParameterCount() + "B\n"
                + "Context Window  : " + getContextWindow() + "\n"
                + "Available Slots : " + availableSlots;
    }
}
