import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;

/**
 * Main GUI window for managing AI subscription plans.
 * Lets you create Personal and Pro plans, submit prompts,
 * manage team members, and export/load plan data.
 *
 * @author Sudip Bharati
 * @version 1.0
 */
public class SubscriptionGUI extends JFrame implements ActionListener {

    // ── Colours ───────────────────────────────────────────────────
    private static final Color BG        = new Color(0xF5F4F2);   // warm off-white background
    private static final Color PANEL_BG  = Color.WHITE;
    private static final Color BORDER_C  = new Color(0xDDDBD8);
    private static final Color TEXT      = new Color(0x1A1A1A);
    private static final Color MUTED     = new Color(0x888580);
    private static final Color ACCENT    = new Color(0x2B2B2B);   // near-black buttons
    private static final Color ACCENT_HV = new Color(0x484848);   // button hover shade
    private static final Color FIELD_BG  = new Color(0xFAF9F7);
    private static final Color OUT_BG    = new Color(0x1C1C1C);   // dark terminal output pane
    private static final Color OUT_TEXT  = new Color(0xD4D0CA);
    private static final Color ERR_TEXT  = new Color(0xE07070);   // red for errors

    private static final Font  LABEL_F   = new Font("SansSerif", Font.PLAIN, 12);
    private static final Font  MONO_F    = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    // ── Data ──────────────────────────────────────────────────────
    private final ArrayList<AIModel> plans = new ArrayList<>();

    // ── Input fields ──────────────────────────────────────────────
    private final JTextField tfModelName  = field(16);
    private final JTextField tfPrice      = field(10);
    private final JTextField tfParams     = field(10);
    private final JTextField tfContext    = field(10);
    private final JTextField tfQuota      = field(10);
    private final JTextField tfSlots      = field(10);
    private final JTextField tfIndex       = field(6);
    private final JTextField tfPromptIndex = field(6);
    private final JTextField tfPromptText = field(22);
    private final JTextField tfOutputLen  = field(10);
    private final JTextField tfMemberName = field(16);

    // ── Output area ───────────────────────────────────────────────
    private final JTextArea taOutput = new JTextArea(10, 48);

    // ── Buttons ───────────────────────────────────────────────────
    private final JButton btnAddPersonal = btn("Add Personal Plan");
    private final JButton btnAddPro      = btn("Add Pro Plan");
    private final JButton btnDisplayAll  = btn("Display All");
    private final JButton btnClear       = ghostBtn("Clear");
    private final JButton btnGivePrompt  = btn("Submit Prompt");
    private final JButton btnAddMember   = btn("Add Member");
    private final JButton btnRmvMember   = ghostBtn("Remove Member");
    private final JButton btnCheckType   = ghostBtn("Check Type");
    private final JButton btnBuyPrompts  = ghostBtn("Buy Prompts");
    private final JButton btnExport      = ghostBtn("Export to File");
    private final JButton btnLoad        = ghostBtn("Load From File");

    /**
     * Builds the window and shows it.
     */
    public SubscriptionGUI() {
        super("AI Subscription Manager");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        JPanel wrap = new JPanel(new BorderLayout(12, 12));
        wrap.setBackground(BG);
        wrap.setBorder(new EmptyBorder(16, 16, 16, 16));
        wrap.add(buildHeader(),       BorderLayout.NORTH);
        wrap.add(buildBody(),         BorderLayout.CENTER);
        wrap.add(buildOutputPanel(),  BorderLayout.SOUTH);
        add(wrap);

        for (JButton b : new JButton[]{btnAddPersonal, btnAddPro, btnDisplayAll,
                btnClear, btnGivePrompt, btnAddMember, btnRmvMember,
                btnCheckType, btnBuyPrompts, btnExport, btnLoad}) {
            b.addActionListener(this);
        }

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ── UI builders ───────────────────────────────────────────────

    /** Builds the title + subtitle header at the top. */
    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setBackground(BG);

        JLabel title = new JLabel("AI Subscription Manager");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setForeground(TEXT);

        JLabel sub = new JLabel("Create and manage AI model subscription plans");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        sub.setForeground(MUTED);

        JPanel textBlock = new JPanel(new GridLayout(2, 1, 0, 2));
        textBlock.setBackground(BG);
        textBlock.add(title);
        textBlock.add(sub);

        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_C);

        p.add(textBlock, BorderLayout.CENTER);
        p.add(sep,       BorderLayout.SOUTH);
        return p;
    }

    /** Two-column layout: plan details on the left, prompt/team on the right. */
    private JPanel buildBody() {
        JPanel p = new JPanel(new GridLayout(1, 2, 12, 0));
        p.setBackground(BG);
        p.add(buildPlanCard());
        p.add(buildRightColumn());
        return p;
    }

    /** Left card: input fields for creating Personal and Pro plans. */
    private JPanel buildPlanCard() {
        JPanel card = card();
        card.setLayout(new BorderLayout(0, 10));
        card.add(sectionLabel("Plan Details"), BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridBagLayout());
        grid.setBackground(PANEL_BG);
        GridBagConstraints g = gbc();

        row(grid, g, 0, "Model Name",           tfModelName);
        row(grid, g, 1, "Price  (Rs / 1L tok)", tfPrice);
        row(grid, g, 2, "Parameters  (B)",      tfParams);
        row(grid, g, 3, "Context Window",       tfContext);

        // Personal Plan section
        g.gridx = 0; g.gridy = 4; g.gridwidth = 2; g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(8, 0, 2, 0);
        JSeparator div1 = new JSeparator(); div1.setForeground(BORDER_C);
        grid.add(div1, g);

        g.gridy = 5; g.insets = new Insets(4, 0, 4, 0);
        JLabel lp = new JLabel("Personal Plan");
        lp.setFont(new Font("SansSerif", Font.BOLD, 11)); lp.setForeground(MUTED);
        grid.add(lp, g);

        g.gridwidth = 1; g.insets = new Insets(4, 0, 4, 10); g.fill = GridBagConstraints.NONE;
        row(grid, g, 6, "Prompt Quota", tfQuota);

        // Pro Plan section
        g.gridx = 0; g.gridy = 7; g.gridwidth = 2; g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(10, 0, 2, 0);
        JSeparator div2 = new JSeparator(); div2.setForeground(BORDER_C);
        grid.add(div2, g);

        g.gridy = 8; g.insets = new Insets(4, 0, 4, 0);
        JLabel lpr = new JLabel("Pro Plan");
        lpr.setFont(new Font("SansSerif", Font.BOLD, 11)); lpr.setForeground(MUTED);
        grid.add(lpr, g);

        g.gridwidth = 1; g.insets = new Insets(4, 0, 4, 10); g.fill = GridBagConstraints.NONE;
        row(grid, g, 9, "Team Slots", tfSlots);

        card.add(grid, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6));
        btns.setBackground(PANEL_BG);
        btns.add(btnAddPersonal);
        btns.add(btnAddPro);
        btns.add(btnDisplayAll);
        btns.add(btnClear);
        btns.add(btnExport);
        btns.add(btnLoad);
        card.add(btns, BorderLayout.SOUTH);

        return card;
    }

    /** Right column with two stacked cards: prompt submission and team management. */
    private JPanel buildRightColumn() {
        JPanel col = new JPanel(new GridLayout(2, 1, 0, 12));
        col.setBackground(BG);

        // Prompt card
        JPanel promptCard = card();
        promptCard.setLayout(new BorderLayout(0, 10));
        promptCard.add(sectionLabel("Submit a Prompt"), BorderLayout.NORTH);

        JPanel pg = new JPanel(new GridBagLayout());
        pg.setBackground(PANEL_BG);
        GridBagConstraints pgc = gbc();
        row(pg, pgc, 0, "Plan Index",    tfPromptIndex);
        row(pg, pgc, 1, "Prompt Text",   tfPromptText);
        row(pg, pgc, 2, "Output Tokens", tfOutputLen);
        promptCard.add(pg, BorderLayout.CENTER);

        JPanel pb = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pb.setBackground(PANEL_BG);
        pb.add(btnGivePrompt);
        pb.add(btnCheckType);
        pb.add(btnBuyPrompts);
        promptCard.add(pb, BorderLayout.SOUTH);

        // Team card
        JPanel teamCard = card();
        teamCard.setLayout(new BorderLayout(0, 10));
        teamCard.add(sectionLabel("Team Management  —  Pro Plan only"), BorderLayout.NORTH);

        JPanel tg = new JPanel(new GridBagLayout());
        tg.setBackground(PANEL_BG);
        GridBagConstraints tgc = gbc();
        row(tg, tgc, 0, "Plan Index",  tfIndex);
        row(tg, tgc, 1, "Member Name", tfMemberName);
        teamCard.add(tg, BorderLayout.CENTER);

        JPanel tb = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        tb.setBackground(PANEL_BG);
        tb.add(btnAddMember);
        tb.add(btnRmvMember);
        teamCard.add(tb, BorderLayout.SOUTH);

        col.add(promptCard);
        col.add(teamCard);
        return col;
    }

    /** Dark terminal-style output panel at the bottom. */
    private JPanel buildOutputPanel() {
        JPanel p = new JPanel(new BorderLayout(0, 5));
        p.setBackground(BG);

        JLabel lbl = new JLabel("OUTPUT");
        lbl.setFont(new Font("Monospaced", Font.BOLD, 10));
        lbl.setForeground(MUTED);
        p.add(lbl, BorderLayout.NORTH);

        taOutput.setEditable(false);
        taOutput.setFont(MONO_F);
        taOutput.setBackground(OUT_BG);
        taOutput.setForeground(OUT_TEXT);
        taOutput.setCaretColor(OUT_TEXT);
        taOutput.setSelectionColor(new Color(0x444444));
        taOutput.setBorder(new EmptyBorder(10, 12, 10, 12));
        taOutput.setLineWrap(true);
        taOutput.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(taOutput);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_C));
        scroll.getViewport().setBackground(OUT_BG);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Button handler ────────────────────────────────────────────

    /** Routes each button click to the right method. */
    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        if      (src == btnAddPersonal) addPersonalPlan();
        else if (src == btnAddPro)      addProPlan();
        else if (src == btnDisplayAll)  displayAll();
        else if (src == btnClear)       clearFields();
        else if (src == btnGivePrompt)  givePrompt();
        else if (src == btnAddMember)   addTeamMember();
        else if (src == btnRmvMember)   removeTeamMember();
        else if (src == btnBuyPrompts)  buyPrompts();
        else if (src == btnCheckType)   { int i = validPromptIndex(); if (i >= 0) checkPlanType(i); }
        else if (src == btnExport)      exportToFile();
        else if (src == btnLoad)        loadFromFile();
    }

    // ── Actions ───────────────────────────────────────────────────

    /** Reads the form fields and creates a new Personal Plan. */
    private void addPersonalPlan() {
        try {
            String name  = require(tfModelName, "Model Name");
            double price = parseDouble(tfPrice, "Price");
            int params   = parseInt(tfParams, "Parameters");
            String ctx   = require(tfContext, "Context Window");
            int quota    = parseInt(tfQuota, "Prompt Quota");

            PersonalPlan pp = new PersonalPlan(name, price, params, ctx, quota);
            plans.add(pp);
            print("✓  Personal Plan added at index " + (plans.size() - 1) + "\n\n" + pp.display());
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Reads the form fields and creates a new Pro Plan. */
    private void addProPlan() {
        try {
            String name  = require(tfModelName, "Model Name");
            double price = parseDouble(tfPrice, "Price");
            int params   = parseInt(tfParams, "Parameters");
            String ctx   = require(tfContext, "Context Window");
            int slots    = parseInt(tfSlots, "Team Slots");

            ProPlan pro = new ProPlan(name, price, params, ctx, slots);
            plans.add(pro);
            print("✓  Pro Plan added at index " + (plans.size() - 1) + "\n\n" + pro.display());
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Prints all plans to the output area with their index. */
    private void displayAll() {
        if (plans.isEmpty()) { print("No plans added yet."); return; }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < plans.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append("── Index ").append(i).append(" ──────────────────────\n");
            sb.append(plans.get(i).display()).append("\n");
        }
        print(sb.toString().trim());
    }

    /** Clears all input fields and the output area. */
    private void clearFields() {
        for (JTextField tf : new JTextField[]{tfModelName, tfPrice, tfParams, tfContext,
                tfQuota, tfSlots, tfPromptText, tfOutputLen, tfMemberName, tfIndex, tfPromptIndex}) {
            tf.setText("");
        }
        taOutput.setText("");
        taOutput.setForeground(OUT_TEXT);
    }

    /** Takes the prompt from the form and submits it to the selected plan. */
    private void givePrompt() {
        try {
            int idx      = validPromptIndex(); if (idx < 0) return;
            String text  = require(tfPromptText, "Prompt Text");
            int outLen   = parseInt(tfOutputLen, "Output Tokens");
            print(plans.get(idx).enterPrompt(text, outLen));
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Adds a team member to a Pro Plan. Shows an error if the plan is Personal. */
    private void addTeamMember() {
        try {
            int idx = validIndex(); if (idx < 0) return;
            String name = require(tfMemberName, "Member Name");
            AIModel m = plans.get(idx);
            if (m instanceof ProPlan)
                print(((ProPlan) m).addTeamMember(name));
            else
                error("Index " + idx + " is a Personal Plan.\nTeam management is only available on Pro Plans.");
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Removes a team member from a Pro Plan. */
    private void removeTeamMember() {
        try {
            int idx = validIndex(); if (idx < 0) return;
            String name = require(tfMemberName, "Member Name");
            AIModel m = plans.get(idx);
            if (m instanceof ProPlan)
                print(((ProPlan) m).removeTeamMember(name));
            else
                error("Index " + idx + " is not a Pro Plan.");
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Buys more prompts for a Personal Plan. Won't work on Pro Plans. */
    private void buyPrompts() {
        try {
            int idx    = validPromptIndex(); if (idx < 0) return;
            int amount = parseInt(tfQuota, "Prompt Quota (amount to add)");
            AIModel m  = plans.get(idx);
            if (m instanceof PersonalPlan)
                print(((PersonalPlan) m).buyPrompts(amount));
            else
                error("Index " + idx + " is a Pro Plan.\nOnly Personal Plans have a prompt quota.");
        } catch (InputEx ex) { error(ex.getMessage()); }
    }

    /** Shows whether the plan at this index is Personal or Pro, plus its details. */
    private void checkPlanType(int idx) {
        AIModel m = plans.get(idx);
        String type = (m instanceof PersonalPlan) ? "Personal Plan"
                    : (m instanceof ProPlan)       ? "Pro Plan"
                    : "Unknown";
        print("Index " + idx + "  →  " + type + "\n\n" + m.display());
    }

    /** Saves all current plans to plans.txt in the working directory. */
    private void exportToFile() {
        if (plans.isEmpty()) {
            error("No plans to export.");
            return;
        }
        try (java.io.PrintWriter out = new java.io.PrintWriter(new java.io.FileWriter("plans.txt"))) {
            for (int i = 0; i < plans.size(); i++) {
                if (i > 0) out.println("\n");
                out.println("── Index " + i + " ──────────────────────");
                out.println(plans.get(i).display());
            }
            print("Successfully exported all plans to 'plans.txt'.");
        } catch (java.io.IOException ex) {
            error("Failed to export: " + ex.getMessage());
        }
    }

    /** Loads plans.txt and shows it in a separate read-only window. */
    private void loadFromFile() {
        java.io.File file = new java.io.File("plans.txt");
        if (!file.exists()) {
            error("No exported file found ('plans.txt').");
            return;
        }
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(file))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            
            JFrame frame = new JFrame("Loaded Plans");
            JTextArea textArea = new JTextArea(sb.toString());
            textArea.setEditable(false);
            textArea.setFont(MONO_F);
            textArea.setBackground(OUT_BG);
            textArea.setForeground(OUT_TEXT);
            textArea.setBorder(new EmptyBorder(10, 10, 10, 10));
            
            JScrollPane scroll = new JScrollPane(textArea);
            scroll.setBorder(BorderFactory.createLineBorder(BORDER_C));
            frame.add(scroll);
            frame.setSize(500, 400);
            frame.setLocationRelativeTo(this);
            frame.setVisible(true);
            
            print("File loaded and displayed successfully in a separate window.");
        } catch (java.io.IOException ex) {
            error("Failed to load: " + ex.getMessage());
        }
    }

    // ── Index validation ──────────────────────────────────────────

    /**
     * Validates the index from the team management field.
     *
     * @return the index, or -1 if it's invalid
     */
    private int validIndex() {
        String raw = tfIndex.getText().trim();
        int idx;
        try { idx = Integer.parseInt(raw); }
        catch (NumberFormatException ex) { error("Plan Index must be a whole number."); return -1; }
        if (plans.isEmpty())             { error("No plans have been added yet."); return -1; }
        if (idx < 0 || idx >= plans.size()) {
            error("Index " + idx + " is out of range.  Valid: 0 – " + (plans.size() - 1));
            return -1;
        }
        return idx;
    }

    /**
     * Validates the index from the prompt submission field.
     *
     * @return the index, or -1 if it's invalid
     */
    private int validPromptIndex() {
        String raw = tfPromptIndex.getText().trim();
        int idx;
        try { idx = Integer.parseInt(raw); }
        catch (NumberFormatException ex) { error("Plan Index must be a whole number."); return -1; }
        if (plans.isEmpty())             { error("No plans have been added yet."); return -1; }
        if (idx < 0 || idx >= plans.size()) {
            error("Index " + idx + " is out of range.  Valid: 0 – " + (plans.size() - 1));
            return -1;
        }
        return idx;
    }

    // ── Input helpers ─────────────────────────────────────────────

    /**
     * Returns the field's text, or throws if it's empty.
     *
     * @param tf   the field to check
     * @param name used in the error message
     * @return trimmed text value
     * @throws InputEx if the field is empty
     */
    private String require(JTextField tf, String name) throws InputEx {
        String v = tf.getText().trim();
        if (v.isEmpty()) throw new InputEx(name + " cannot be empty.");
        return v;
    }

    /**
     * Parses the field as an int, or throws if it's not a valid number.
     *
     * @param tf   the field to parse
     * @param name used in the error message
     * @return parsed int
     * @throws InputEx if parsing fails
     */
    private int parseInt(JTextField tf, String name) throws InputEx {
        try { return Integer.parseInt(tf.getText().trim()); }
        catch (NumberFormatException ex) { throw new InputEx(name + " must be a whole number."); }
    }

    /**
     * Parses the field as a double, or throws if it's not a valid number.
     *
     * @param tf   the field to parse
     * @param name used in the error message
     * @return parsed double
     * @throws InputEx if parsing fails
     */
    private double parseDouble(JTextField tf, String name) throws InputEx {
        try { return Double.parseDouble(tf.getText().trim()); }
        catch (NumberFormatException ex) { throw new InputEx(name + " must be a number."); }
    }

    /** Simple exception used internally when a field has bad or missing input. */
    private static class InputEx extends Exception {
        InputEx(String m) { super(m); }
    }

    // ── Output helpers ────────────────────────────────────────────

    /** Prints a normal message to the output area. */
    private void print(String msg) {
        taOutput.setForeground(OUT_TEXT);
        taOutput.setText(msg);
    }

    /** Prints an error in red and shows a popup dialog. */
    private void error(String msg) {
        taOutput.setForeground(ERR_TEXT);
        taOutput.setText("Error  —  " + msg);
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // ── Widget helpers ────────────────────────────────────────────

    /** Creates a styled text field with the given column width. */
    private static JTextField field(int cols) {
        JTextField tf = new JTextField(cols);
        tf.setFont(LABEL_F);
        tf.setBackground(FIELD_BG);
        tf.setForeground(TEXT);
        tf.setCaretColor(TEXT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_C),
            new EmptyBorder(4, 7, 4, 7)));
        return tf;
    }

    /** Filled dark button - used for primary actions. */
    private static JButton btn(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? ACCENT_HV : ACCENT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 6, 6));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleBtn(b);
        b.setForeground(Color.WHITE);
        return b;
    }

    /** Outlined ghost button - used for secondary actions. */
    private static JButton ghostBtn(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(0xECEAE6) : PANEL_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 6, 6));
                g2.setColor(BORDER_C);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 6, 6));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleBtn(b);
        b.setForeground(TEXT);
        return b;
    }

    /** Shared button styling - font, border, cursor, etc. */
    private static void styleBtn(JButton b) {
        b.setFont(new Font("SansSerif", Font.PLAIN, 12));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(6, 13, 6, 13));
    }

    /** White card panel with a light border and padding. */
    private static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(PANEL_BG);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_C),
            new EmptyBorder(14, 16, 14, 16)));
        return p;
    }

    /** Small bold section label shown at the top of each card. */
    private static JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text.toUpperCase());
        l.setFont(new Font("SansSerif", Font.BOLD, 10));
        l.setForeground(MUTED);
        l.setBorder(new EmptyBorder(0, 0, 4, 0));
        return l;
    }

    /** Default GridBagConstraints used for all form rows. */
    private static GridBagConstraints gbc() {
        GridBagConstraints g = new GridBagConstraints();
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(4, 0, 4, 10);
        return g;
    }

    /** Adds a label + input field as one row in a GridBagLayout panel. */
    private static void row(JPanel p, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridwidth = 1; g.fill = GridBagConstraints.NONE; g.weightx = 0;
        g.gridx = 0; g.gridy = row;
        JLabel l = new JLabel(label);
        l.setFont(LABEL_F); l.setForeground(MUTED);
        p.add(l, g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1.0;
        p.add(field, g);
        g.weightx = 0;
    }

    /**
     * Entry point - launches the GUI on the Swing event thread.
     *
     * @param args not used
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new SubscriptionGUI();
        });
    }
}
