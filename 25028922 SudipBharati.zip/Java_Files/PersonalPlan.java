/**
 * Personal subscription plan with a limited monthly prompt quota.
 * Users run out of prompts and need to buy more or upgrade to Pro.
 *
 * @author Sudip Bharati
 * @version 1.0
 */
public class PersonalPlan extends AIModel {

    private int promptsRemaining; // how many prompts the user has left this month

    /**
     * Creates a Personal Plan.
     *
     * @param modelName        name of the AI model
     * @param price            cost per 100,000 tokens in Rs.
     * @param parameterCount   parameter count in billions
     * @param contextWindow    max context size e.g. "64K"
     * @param promptsRemaining starting prompt quota for the month
     */
    public PersonalPlan(String modelName, double price, int parameterCount, String contextWindow, int promptsRemaining) {
        super(modelName, price, parameterCount, contextWindow);
        this.promptsRemaining = promptsRemaining;
    }

    /**
     * @return how many prompts the user still has left
     */
    public int getPromptsRemaining() {
        return promptsRemaining;
    }

    /**
     * Adds more prompts to the user's quota.
     * Amount must be positive, otherwise suggests upgrading to Pro.
     *
     * @param amount number of prompts to add
     * @return confirmation or error message
     */
    public String buyPrompts(int amount) {
        if (amount <= 0) {
            return "Please enter a positive number of prompts, or consider upgrading to Pro Plan.";
        }
        promptsRemaining += amount;
        return amount + " prompt(s) added. Prompts remaining: " + promptsRemaining;
    }

    /**
     * Submits a prompt if the user has quota left and it fits in the context window.
     * Deducts one prompt on success.
     *
     * @param promptText   the prompt text
     * @param outputTokens expected output token count
     * @return result summary or error message
     */
    @Override
    public String enterPrompt(String promptText, int outputTokens) {
        if (promptsRemaining <= 0) {
            return "Monthly prompt limit reached. Please buy more prompts or upgrade to Pro Plan.";
        }

        int totalTokens = calculateTokens(promptText, outputTokens);
        int contextLimit = getContextWindowAsInt();

        if (totalTokens > contextLimit) {
            return "Request exceeds context window (" + getContextWindow() + "). "
                    + "Total tokens required: " + totalTokens + ". Please shorten your prompt or reduce the expected output length.";
        }

        promptsRemaining--;
        return "Prompt submitted successfully.\n"
                + "Model     : " + getModelName() + "\n"
                + "Prompt    : " + promptText + "\n"
                + "Tokens    : " + totalTokens + " (input + output)\n"
                + "Prompts remaining: " + promptsRemaining;
    }

    /**
     * @return formatted plan summary including prompts remaining
     */
    @Override
    public String display() {
        return "[ Personal Plan ]\n"
                + "Model Name      : " + getModelName() + "\n"
                + "Price (per 1L tokens) : Rs. " + getPrice() + "\n"
                + "Parameters      : " + getParameterCount() + "B\n"
                + "Context Window  : " + getContextWindow() + "\n"
                + "Prompts Remaining: " + promptsRemaining;
    }
}
